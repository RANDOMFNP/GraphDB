// Derivative work from: https://www.phoenixdata.ai/glossary/depth-first-search-dfs

namespace graphlib {

template<typename node>

std::vector<node> dfs_algorithm(node starting_value, std::string input_file) {
    std::unordered_set<node> visited;
    std::stack<node> stack_of_numbers;
    std::unordered_map<node, std::vector<node>> graph;
    graph = parse<node>(input_file);
    
    stack_of_numbers.push(starting_value);

    std::vector<node> return_vector;

    while (!stack_of_numbers.empty()) {
        node current = stack_of_numbers.top();
        stack_of_numbers.pop();

        if (visited.contains(current)) {
            continue;
        }

        visited.insert(current);
        return_vector.push_back(current);

        auto it = graph.find(current);
        if (it == graph.end()) {
            continue;
        }
            for (auto neighbor : it->second) {
                stack_of_numbers.push(neighbor);
            }
        }
    return return_vector;
}
}